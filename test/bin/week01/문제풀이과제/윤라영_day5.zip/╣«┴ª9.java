package week01.문제풀이과제;

public class 문제9 {

	public static void main(String[] args) {
		// *(별) 1개로 3개 출력

		
		for(int i=0; i<3; i++) {
			System.out.print("*"); // print =>줄바꿈X  println => 줄바꿈O
		}
	}

}
