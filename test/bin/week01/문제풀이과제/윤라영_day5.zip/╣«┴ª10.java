package week01.문제풀이과제;

public class 문제10 {

	public static void main(String[] args) {
		// *(별) 1개로 3개를 3줄 출력

		
		for(int i=1; i<=3; i++) {  //3줄
			for(int j=1; j<=3; j++) {
				System.out.print("*");
			}
			System.out.println();
		}
		
	}

}
