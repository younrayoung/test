package week01.문제풀이과제;

public class 문제2 {

	public static void main(String[] args) {
		// 1~10 거꾸로 출력하기
		
		for(int i=10; i>=1;i--) {
			System.out.println(i);
		}
	}

}
