package week01.문제풀이과제;

public class 문제8 {

	public static void main(String[] args) {
		// *(별) 1개 출력

		
		
		
		// char사용
		char a='*';
			System.out.println(a);
		
		
		//for문 사용
		for(int i=0; i<1; i++) {
			System.out.print("*");
		}
	}

}
